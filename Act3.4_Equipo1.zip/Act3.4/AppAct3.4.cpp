// Programa para desplegar las 5 ips con mayor accesos mediante una estructura BST
// Equipo 1: Noemi Carolina Guerra Montiel A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Domingo 25 de octubre del 2020

#include <iostream>
#include <string>
#include <fstream>
#include <queue>

using namespace std;
#include "BST.h"

// Convierte la ip a key
// Complejidad: O(n)
long ipToLong(string ip){
	int idx = 0;
	long datoFinal= 0, dato = 0;
	while (idx < ip.size() && ip[idx]!=':'){
		if (ip[idx]!= '.'){
			dato = dato*10 + ip[idx]-'0';
		}
		else{
			datoFinal = datoFinal*1000 + dato;
			dato = 0;
		}
		idx++;
	}
	datoFinal = datoFinal*10000 + dato;
	return datoFinal;
}

// Carga los datos del archivo bitacoraOrdenada
// Complejidad: O(n)
void cargaIpsBitacora(BST &arbol){
    string mes, hora, dirIp, razon;
    int dia;
    long ipNueva;
    long ipAnt = 0;
    int contAcc = 0;

    ifstream archivo;
    archivo.open("bitacoraOrdenada.txt");

    while(archivo>>mes>>dia>>hora>>dirIp){
        getline(archivo, razon);
        ipNueva = ipToLong(dirIp);
        if(ipNueva != ipAnt && contAcc >= 0){
            arbol.add(ipAnt, contAcc);
            ipAnt = ipNueva;
            contAcc = 1;
        }
        else{
            contAcc++;
        }
    }
    arbol.add(ipAnt, contAcc);
    archivo.close();
}

int main() {
  BST arbol;

  cargaIpsBitacora(arbol);
  cout << "Direcciones ip con mayor numero de accesos: " << endl;
  arbol.print();
  
  return 0;
}