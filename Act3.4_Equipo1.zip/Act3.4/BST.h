// ADT de BST (Arbol binario de busqueda)
// Equipo 1: Noemi Carolina Guerra Montiel A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Domingo 25 de octubre del 2020

#include "NodeT.h"
#include<sstream>

class BST{
public:
    BST();
    ~BST();
    void add(long ip, int cantAccesos);
    int size();
    void print();
private:
    NodeT *root;
    queue<int> listaAcc;
    queue<long> listaIps;
    void inOrden(NodeT *r);
    void destruye(NodeT *r);
    int sizeHelper(NodeT *r);
    string longToip(long lip);
};

// Constructor
// Complejidad: O(1)
BST::BST(){
    root = nullptr;
}

// Destructor
// Complejidad: O(n)
BST::~BST(){
    destruye(root);
}

// Ayuda al destructor a eliminar el arbol
// Complejidad: O(n)
void BST::destruye(NodeT *r){
    if(r!=nullptr){
        destruye(r->getLeft());
        destruye(r->getRight());
        delete r;
    }
}

// Agrega un nodo al arbol
// Complejidad: O(altura del arbol)
void BST::add(long ip, int cantAccesos){
    NodeT *curr = root;
    NodeT *father = nullptr;

    while(curr!=nullptr){
        father = curr;
        
        if(curr->getAccesos() > cantAccesos){
            curr = curr->getLeft();
        }
        else if(curr->getAccesos() < cantAccesos){
            curr = curr->getRight();
        }
        else{
            curr = (curr->getIp() > ip) ? curr->getRight() : curr->getLeft();
        }
    }

    if(father == nullptr){
        root = new NodeT(ip, cantAccesos);
    }
    else{
        if(father->getAccesos() > cantAccesos){
          father->setLeft(new NodeT(ip, cantAccesos));
        }
        else if(father->getAccesos() < cantAccesos){
          father->setRight(new NodeT(ip, cantAccesos));
        }
        else{
          (father->getIp() > ip) ? father->setRight(new NodeT(ip, cantAccesos)) : father->setLeft(new NodeT(ip, cantAccesos));
        }
    }
}

// Desplega los datos en inOrden converso
// Complejidad: O(n)
void BST::inOrden(NodeT *r){
    int cont = 0;
    if(r!=nullptr){
        inOrden(r->getRight());
        listaIps.push(r->getIp());
        listaAcc.push(r->getAccesos());
        inOrden(r->getLeft());
    }
}

// Convierte de long a ip
// Complejidad: O(n)
string BST::longToip(long lip){
  string s;
  stringstream ss;  
  ss<<lip;  
  ss>>s;

  s = s.substr(0,2) + "." + s.substr(3,2) + "." + s.substr(5,3) +"."+ s.substr(9,s.length());
    
return s;
}

// Despliega el resultado de las 5 ips con más accesos 
// Complejidad: O(n)
void BST::print(){
    inOrden(root);
    for (int i = 1; i <= 5; i++){

      cout << i << "°-" << longToip(listaIps.front()) << " " << listaAcc.front() << " accesos" << endl;
      listaIps.pop();
      listaAcc.pop();
    }
}

// Ayuda a obtener el tamano de un arbol
// Compljidad: O(n)
int BST::sizeHelper(NodeT *r){
    if(r == nullptr){
        return 0;
    }
    return 1 + sizeHelper(r->getLeft()) + sizeHelper(r->getRight());
}

// Regresa la cantidad de nodos (tamano) del arbol
// Compljidad: O(n)
int BST::size(){
    return sizeHelper(root);
}

