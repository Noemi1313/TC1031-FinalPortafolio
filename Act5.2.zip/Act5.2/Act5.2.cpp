// Act 5.2: Programa que lee una bitacora, crea una tabla hash cuya key es el ip, su valor es un resumen y dado un ip, regresa su valor 
//  Equipo 1: Noemi Carolina Guerra Montiel A00826944, Izac Salazar A01197392 y Hector Guapo A01197463
// Sabado 28 de noviembre del 2020

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>

using namespace std;

// Función para quitar el puerto de la direccion ip
// Complejidad: O(n)
string quitarPuerto(string ip){
    int idx = 0;
    string ipSinPuerto;
    while (idx < ip.size() && ip[idx]!=':')
        ipSinPuerto += ip[idx++];
    return ipSinPuerto;
}

// Estructura para crear un vector capaz de contener los 5 atributos de la loadBitacora
// Complejidad: O(1)
struct resume{
    string dia, mes, hora, razon;
    resume(string dia, string mes, string hora, string razon){
      this->dia = dia;
      this->mes = mes;
      this->hora = hora;
      this->razon = razon;
    }

    string toString(){
        return dia + " " + mes + " " + hora + " " + razon;
    }
};

// Funcion para cargar los datos de la bitacora
// Complejidad: O(n)
void loadBitacora(unordered_map<string, vector<resume>> &mapa){
  string dia, mes, hora, dirIp, ipEnt, razon;
  int numAccesos;
  vector<resume> resumen;
  ifstream archivo;
  archivo.open("bitacoraACT5_2.txt");

  while(archivo>>mes>>dia>>hora>>dirIp){
      getline(archivo, razon);
      dirIp = quitarPuerto(dirIp);
      resume dato(dia, mes, hora, razon);
      mapa[dirIp].push_back(dato);
  }
  archivo.close();
}

// Función para buscar e imprimir un resumen del registro segun la entrada de la ip (key)
// Complejidad: O(1)
void buscaIp(unordered_map<string, vector<resume>> mapa, string key){
  cout << "Numero de Accesos: " << mapa[key].size() << endl;
  for(int i = 0; i<mapa[key].size(); i++){
    cout << " " << mapa[key][i].mes << " " << mapa[key][i].dia << " " << mapa[key][i].hora << " " << mapa[key][i].razon << " " << endl;
  }
}

int main() {
  string ipEnt, opcion;
  unordered_map<string, vector<resume>> mapa;

  loadBitacora(mapa);

  do {
  cout << "Ingrese la ip: " << endl;
  cin >> ipEnt;

  buscaIp(mapa, ipEnt);

  cout << "Desea seguir? Ingrese si o no: ";
  cin >> opcion;
  cout << endl;
  } while(opcion != "no");

  return 0;
}
